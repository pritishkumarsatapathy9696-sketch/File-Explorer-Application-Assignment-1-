// file_explorer.cpp
// to compile: g++ -std=c++17 -O2 -Wall file_explorer.cpp -o file_explorer
// Run: ./file_explorer
#include <fstream> 

void addToHistory(const std::string& entry) {
    std::ofstream historyFile("command_history.txt", std::ios::app);
    if (historyFile.is_open()) {
        historyFile << entry << "\n";
        historyFile.close();
    }
}

#include <fstream>
#include <chrono>
#include <iomanip>
#include <bits/stdc++.h>
#include <filesystem>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <unistd.h>
#include <sys/stat.h>


namespace fs = std::filesystem;

using std::string;
using std::vector;
using std::cout;
using std::cin;
using std::endl;

std::string getPermissionString(mode_t mode) {
    std::string perm;
    perm += (mode & S_IRUSR) ? "r" : "-";
    perm += (mode & S_IWUSR) ? "w" : "-";
    perm += (mode & S_IXUSR) ? "x" : "-";
    perm += (mode & S_IRGRP) ? "r" : "-";
    perm += (mode & S_IWGRP) ? "w" : "-";
    perm += (mode & S_IXGRP) ? "x" : "-";
    perm += (mode & S_IROTH) ? "r" : "-";
    perm += (mode & S_IWOTH) ? "w" : "-";
    perm += (mode & S_IXOTH) ? "x" : "-";
    return perm;
}


static void cmd_perm(const std::vector<std::string>& args) {
    if (args.size() < 2) {
        std::cout << "Usage: perm <filename>\n";
        return;
    }

    struct stat fileStat;
    if (stat(args[1].c_str(), &fileStat) < 0) {
        std::cout << "Error: unable to read file permissions.\n";
        return;
    }

    std::cout << "Permissions for " << args[1] << ": " << getPermissionString(fileStat.st_mode) << "\n";
}

// Change permissions
static void cmd_chmod(const std::vector<std::string>& args) {
    if (args.size() < 3) {
        std::cout << "Usage: chmod <filename> <octal_permission>\n";
        return;
    }

    std::string filename = args[1];
    std::string permStr = args[2];

    try {
        mode_t permissions = std::stoi(permStr, nullptr, 8);
        if (chmod(filename.c_str(), permissions) == 0) {
            std::cout << "Permissions updated for " << filename << "\n";
            addToHistory("chmod " + filename + " " + permStr);
        } else {
            std::cout << "Failed to change permissions.\n";
        }
    } catch (...) {
        std::cout << "Invalid permission format. Use octal (e.g., 755).\n";
    }
}

// Show file owner info
static void cmd_owner(const std::vector<std::string>& args) {
    if (args.size() < 2) {
        std::cout << "Usage: owner <filename>\n";
        return;
    }

    struct stat fileStat;
    if (stat(args[1].c_str(), &fileStat) < 0) {
        std::cout << "Error: unable to read file ownership.\n";
        return;
    }

    struct passwd *pw = getpwuid(fileStat.st_uid);
    struct group  *gr = getgrgid(fileStat.st_gid);

    std::cout << "Owner: " << (pw ? pw->pw_name : "unknown")
              << ", Group: " << (gr ? gr->gr_name : "unknown") << "\n";
}

static string promptPath() {
    char buf[PATH_MAX];
    if (getcwd(buf, sizeof(buf))) return string(buf);
    return string(".");
}

static string joinArgs(const vector<string>& args, size_t start=0) {
    string s;
    for (size_t i = start; i < args.size(); ++i) {
        if (i>start) s += " ";
        s += args[i];
    }
    return s;
}

static void print_help() {
    cout <<
    "Commands:\n"
    " ls [path]               : list directory (ls -l style)\n"
    " cd <dir>                : change directory\n"
    " pwd                     : show current directory\n"
    " view <file>             : print file content (paged)\n"
    " cp <src> <dst>          : copy file or directory (dst can be dir)\n"
    " mv <src> <dst>          : move/rename\n"
    " rm [-r] <path>          : remove file or directory (use -r for directories)\n"
    " mkdir <dir>             : create directory\n"
    " rmdir <dir>             : remove empty directory\n"
    " touch <file>            : create empty file or update mtime\n"
    " info <path>             : show detailed file info\n"
    " search <name> [path]    : search for files/dirs by name (recursive)\n"
    " clear                   : clear screen\n"
    " help                    : show this help\n"
	" history                 : show history\n"
    " exit | quit             : exit\n";
}

static string perms_to_string(mode_t m) {
    string s;
    s += (S_ISDIR(m) ? 'd' : '-');
    s += (m & S_IRUSR) ? 'r' : '-';
    s += (m & S_IWUSR) ? 'w' : '-';
    s += (m & S_IXUSR) ? 'x' : '-';
    s += (m & S_IRGRP) ? 'r' : '-';
    s += (m & S_IWGRP) ? 'w' : '-';
    s += (m & S_IXGRP) ? 'x' : '-';
    s += (m & S_IROTH) ? 'r' : '-';
    s += (m & S_IWOTH) ? 'w' : '-';
    s += (m & S_IXOTH) ? 'x' : '-';
    return s;
}

static void cmd_ls(const vector<string>& args) {
    fs::path target = args.size() > 1 ? args[1] : ".";
    try {
        if (!fs::exists(target)) { cout << "No such file or directory: " << target << "\n"; return; }
        if (fs::is_directory(target)) {
            std::vector<fs::directory_entry> entries;
            for (auto &e : fs::directory_iterator(target)) entries.push_back(e);
            std::sort(entries.begin(), entries.end(), [](auto &a, auto &b) {
                return a.path().filename().string() < b.path().filename().string();
            });
            for (auto &e : entries) {
                struct stat st;
                if (stat(e.path().c_str(), &st) == 0) {
                    cout << perms_to_string(st.st_mode) << ' '
                         << std::setw(6) << st.st_size << ' ';
                    // owner/group
                    struct passwd *pw = getpwuid(st.st_uid);
                    struct group  *gr = getgrgid(st.st_gid);
                    cout << (pw ? pw->pw_name : std::to_string(st.st_uid)) << ' '
                         << (gr ? gr->gr_name : std::to_string(st.st_gid)) << ' ';
                    // mtime
                    char tbuf[64];
                    std::tm *tm = std::localtime(&st.st_mtime);
                    strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M", tm);
                    cout << tbuf << ' ';
                }
                cout << e.path().filename().string() << (fs::is_directory(e) ? "/" : "") << "\n";
            }
        } else {
            // single file
            struct stat st;
            if (stat(target.c_str(), &st) == 0) {
                cout << perms_to_string(st.st_mode) << ' '
                     << std::setw(6) << st.st_size << ' ';
                struct passwd *pw = getpwuid(st.st_uid);
                struct group  *gr = getgrgid(st.st_gid);
                cout << (pw ? pw->pw_name : std::to_string(st.st_uid)) << ' '
                     << (gr ? gr->gr_name : std::to_string(st.st_gid)) << ' ';
                char tbuf[64];
                std::tm *tm = std::localtime(&st.st_mtime);
                strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M", tm);
                cout << tbuf << ' ' << fs::path(target).filename().string() << "\n";
            }
        }
    } catch (std::exception &ex) {
        cout << "ls error: " << ex.what() << "\n";
    }
}

static void cmd_cd(const vector<string>& args) {
    if (args.size() < 2) { cout << "cd: missing argument\n"; return; }
    string path = args[1];
    if (path == "~") path = getenv("HOME") ? getenv("HOME") : path;
    if (chdir(path.c_str()) != 0) perror("cd");
}

static void view_paged(const fs::path &p) {
    if (!fs::exists(p) || fs::is_directory(p)) { cout << "Cannot view: not a regular file\n"; return; }
    std::ifstream in(p);
    if (!in) { cout << "Failed to open file\n"; return; }
    string line;
    int linesShown = 0;
    const int PAGE = 25;
    while (std::getline(in, line)) {
        cout << line << "\n";
        if (++linesShown >= PAGE) {
            cout << "--More-- (Enter to continue, q to quit) ";
            string cmd;
            std::getline(cin, cmd);
            if (!cmd.empty() && (cmd[0]=='q' || cmd[0]=='Q')) return;
            linesShown = 0;
        }
    }
}

static bool copyRecursively(const fs::path& src, const fs::path& dst) {
    try {
        if (fs::is_directory(src)) {
            fs::create_directories(dst);
            for (auto &entry : fs::directory_iterator(src)) {
                if (!copyRecursively(entry.path(), dst / entry.path().filename()))
                    return false;
            }
        } else {
            fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
        }
    } catch (...) { return false; }
    return true;
}

static void cmd_cp(const vector<string>& args) {
    if (args.size() < 3) { cout << "cp: requires src and dst\n"; return; }
    fs::path src(args[1]), dst(args[2]);
    try {
        if (!fs::exists(src)) { cout << "cp: source not found\n"; return; }
        if (fs::is_directory(src) && fs::exists(dst) && !fs::is_directory(dst)) {
            cout << "cp: cannot copy directory into file\n"; return;
        }
        if (fs::is_directory(src)) {
            
            fs::path out = fs::exists(dst) && fs::is_directory(dst) ? dst / src.filename() : dst;
            if (!copyRecursively(src, out)) cout << "cp: failed\n";
        } else {
            if (fs::is_directory(dst)) dst /= src.filename();
            fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
        }
    } catch (std::exception &ex) { cout << "cp error: " << ex.what() << "\n"; }
}

static void cmd_history() {
    std::ifstream historyFile("command_history.txt");
    if (!historyFile.is_open()) {
        cout << "No command history found.\n";
        return;
    }
    string line;
    cout << "--- Command History ---\n";
    while (getline(historyFile, line)) {
        cout << line << "\n";
    }
    historyFile.close();
}


static void cmd_mv(const vector<string>& args) {
    if (args.size() < 3) { cout << "mv: requires src and dst\n"; return; }
    fs::path src(args[1]), dst(args[2]);
    try {
        if (!fs::exists(src)) { cout << "mv: source not found\n"; return; }
        if (fs::is_directory(dst)) dst /= src.filename();
        fs::rename(src, dst);
    } catch (std::exception &ex) {
        try {
            if (copyRecursively(src, dst)) {
                fs::remove_all(src);
            } else cout << "mv: move failed\n";
        } catch (...) { cout << "mv error: " << ex.what() << "\n"; }
    }
}

static void cmd_rm(const vector<string>& args) {
    if (args.size() < 2) { cout << "rm: missing operand\n"; return; }
    bool recursive = false;
    size_t idx = 1;
    if (args[1] == "-r") { recursive = true; idx = 2; }
    if (idx >= args.size()) { cout << "rm: missing operand\n"; return; }
    fs::path target(args[idx]);
    try {
        if (!fs::exists(target)) { cout << "rm: no such file or directory\n"; return; }
        if (fs::is_directory(target) && !recursive) { cout << "rm: is a directory (use -r)\n"; return; }
        if (fs::is_directory(target)) fs::remove_all(target);
        else fs::remove(target);
    } catch (std::exception &ex) { cout << "rm error: " << ex.what() << "\n"; }
}

static void cmd_mkdir(const vector<string>& args) {
    if (args.size() < 2) { cout << "mkdir: missing operand\n"; return; }
    try { fs::create_directories(args[1]);
        addToHistory("mkdir " + args[1]); 
	}
    catch (std::exception &ex) { cout << "mkdir error: " << ex.what() << "\n"; }
}

static void cmd_rmdir(const vector<string>& args) {
    if (args.size() < 2) { cout << "rmdir: missing operand\n"; return; }
    try { fs::remove(args[1]); }
    catch (std::exception &ex) { cout << "rmdir error: " << ex.what() << "\n"; }
}

static void cmd_touch(const vector<string>& args) {
    if (args.size() < 2) { cout << "touch: missing file\n"; return; }
    fs::path p(args[1]);
    try {
        std::ofstream out(p, std::ios::app);
        out.close();
        // update mtime
        std::error_code ec;
        auto now = std::chrono::file_clock::now();
        fs::last_write_time(p, now, ec);
    } catch (std::exception &ex) { cout << "touch error: " << ex.what() << "\n"; }
}

static void cmd_info(const vector<string>& args) {
    if (args.size() < 2) { cout << "info: missing path\n"; return; }
    fs::path p(args[1]);
    try {
        if (!fs::exists(p)) { cout << "No such file or directory\n"; return; }
        struct stat st;
        if (stat(p.c_str(), &st) == 0) {
            cout << "Path: " << p << "\n";
            cout << "Type: " << (fs::is_directory(p) ? "Directory" : "File") << "\n";
            cout << "Size: " << st.st_size << " bytes\n";
            cout << "Permissions: " << perms_to_string(st.st_mode) << "\n";
            struct passwd *pw = getpwuid(st.st_uid);
            struct group  *gr = getgrgid(st.st_gid);
            cout << "Owner: " << (pw ? pw->pw_name : std::to_string(st.st_uid)) << "\n";
            cout << "Group: " << (gr ? gr->gr_name : std::to_string(st.st_gid)) << "\n";
            char tbuf[64];
            std::tm *tm = std::localtime(&st.st_mtime);
            strftime(tbuf, sizeof(tbuf), "%Y-%m-%d %H:%M:%S", tm);
            cout << "Last modified: " << tbuf << "\n";
        } else cout << "stat failed\n";
    } catch (std::exception &ex) { cout << "info error: " << ex.what() << "\n"; }
}

static void cmd_search(const vector<string>& args) {
    if (args.size() < 2) { cout << "search: missing name\n"; return; }
    string name = args[1];
    fs::path start = args.size() > 2 ? fs::path(args[2]) : fs::path(".");
    try {
        if (!fs::exists(start)) { cout << "start path not found\n"; return; }
        for (auto &it : fs::recursive_directory_iterator(start)) {
            if (it.path().filename().string().find(name) != string::npos) {
                cout << it.path().string();
                if (fs::is_directory(it.path())) cout << "/";
                cout << "\n";
            }
        }
    } catch (std::exception &ex) { cout << "search error: " << ex.what() << "\n"; }
}



static vector<string> split_shell(const string &line) {
    std::istringstream iss(line);
    vector<string> out;
    string tok;
    while (iss >> std::quoted(tok)) { out.push_back(tok); } // allows quoted tokens
    // If nothing parsed via quoted, fall back
    if (out.empty()) {
        iss.clear();
        iss.str(line);
        while (iss >> tok) out.push_back(tok);
    }
    return out;
}

bool loginUser(std::string &currentUser) {
    std::string username, password, fileUser, filePass;
    std::cout << "Username: ";
    std::cin >> username;
    std::cout << "Password: ";
    std::cin >> password;

    std::ifstream in("users.txt");
    while (in >> fileUser >> filePass) {
        if (fileUser == username && filePass == password) {
            std::cout << "\nLogin successful.\n";
            currentUser = username;
            return true;
        }
    }
    std::cout << "\nInvalid credentials.\n";
    return false;
}

void registerUser() {
    std::string username, password;
    std::cout << "New Username: ";
    std::cin >> username;
    std::cout << "New Password: ";
    std::cin >> password;

    std::ofstream out("users.txt", std::ios::app);
    out << username << " " << password << "\n";
    std::cout << "\nUser registered successfully.\n";
}

void logAction(const std::string& user, const std::string& action) {
    std::ofstream log("log.txt", std::ios::app);
    auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    log << std::put_time(std::localtime(&now), "%Y-%m-%d %H:%M:%S")
        << " | " << user << " | " << action << "\n";
}


int main() {
    std::string currentUser;
    std::cout << "===== Welcome to Console File Explorer =====\n";
    std::cout << "1. Login\n2. Register\nChoose: ";
    int opt; 
    std::cin >> opt;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); 

    if (opt == 2) {
        registerUser();
        std::cout << "\nPlease login now.\n";
    }

    if (!loginUser(currentUser)) return 0;

    std::cout << "\nHello, " << currentUser << "! Access granted.\n";
    std::cout << "Console File Explorer (simple) — type 'help' for commands\n";

    std::string line;
    while (true) {
        std::cout << promptPath() << " $ ";
        if (!std::getline(std::cin, line)) break;
        if (line.empty()) continue;
        auto args = split_shell(line);
        std::string cmd = args[0];
        if (cmd == "exit" || cmd == "quit") break;
        else if (cmd == "help") print_help();
        else if (cmd == "ls") cmd_ls(args);
        else if (cmd == "cd") cmd_cd(args);
        else if (cmd == "pwd") std::cout << promptPath() << "\n";
        else if (cmd == "view") {
            if (args.size() < 2) { std::cout << "view: missing file\n"; continue; }
            view_paged(args[1]);
        }
        else if (cmd == "chmod") cmd_chmod(args);
        else if (cmd == "perm") cmd_perm(args);
        else if (cmd == "owner") cmd_owner(args);
        else if (cmd == "cp") cmd_cp(args);
        else if (cmd == "mv") cmd_mv(args);
        else if (cmd == "rm") cmd_rm(args);
        else if (cmd == "mkdir") cmd_mkdir(args);
        else if (cmd == "rmdir") cmd_rmdir(args);
        else if (cmd == "touch") cmd_touch(args);
        else if (cmd == "info") cmd_info(args);
        else if (cmd == "search") cmd_search(args);
        else if (cmd == "clear") system("clear");
		else if (cmd == "history") cmd_history();
        else std::cout << "Unknown command: " << cmd << " (type help)\n";
    }

    std::cout << "Bye.\n";
    return 0;
}

